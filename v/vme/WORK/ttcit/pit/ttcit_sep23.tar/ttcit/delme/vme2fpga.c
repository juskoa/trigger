/*
       VME 2 FPGA: Reading, loading TTCit Logic FPGA
 */

#include "vmewrap.h"
#include "ttcit.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "auxttcit.h"

#define Mega 1024*1024
#define kilo 1024

#define MAX_W_ATTEMPTS 4000  /* Max nr of attempts to write into Flash Mem */
#define MAX_R_ATTEMPTS 4000  /* Max nr of attempts to read from Flash Mem */
#define MAX_E_ATTEMPTS 50    /* Max nr of attempts to erase the Flash Mem */
#define ERASE_SLEEP    999999 /* Erase Chip FM sleep - 1 sec */

/*
     FPGA status bits
*/
#define conf_busy 0
#define nStatus   1
#define conf_done 2
#define init_done 3
#define nConfig   4
#define enDclk    5

static struct bufferFM wrtBuffer; /* data (to be) written into Flash Mem */
static struct bufferFM readBuffer; /* data read from the Flash Mem */



/*FGROUP FPGA 
Get status of the FPGA
*/
int GetStatusFPGA(){

  int fpgaStat;
  char statReady[] = "READY\0";
  char statBusy[] = "BUSY\0";
  char statUnknown[] = "UNKNOWN\0";
  char *st;

  fpgaStat = GetStatFPGA();
  switch(fpgaStat){
  case READYFP:
    st = &statReady[0];
    break;
  case BUSYFP:
    st = &statBusy[0];
    break;
  default:
    st = &statUnknown[0];
    break;
  }
  printf("FPGA status is %i = %s \n",fpgaStat,st);

  return fpgaStat;
}

int GetStatFPGA(){
  int stat;
  w32 status;
  w32 bit0 = 1;

  status = VMER32(CONFIG_STATUS);
  stat = ( (status & bit0 ) == bit0 );
  return stat;
}

/* --------------------------------------
 */

/*FGROUP FlMem 
Get status of the FLASH memory
*/
int GetStatusFM(){
  int flMemStat;
  char statReady[] = "READY\0";
  char statBusy[] = "BUSY\0";
  char statUnknown[] = "Unknown\0";
  char *st;

  flMemStat = GetStatFM();
  switch(flMemStat){
  case READYFM:
    st = &statReady[0];
    break;
  case BUSYFM:
    st = &statBusy[0];
    break;
  default:
    st = &statUnknown[0];
    break;
  }
  printf("Flash Memory status   %i = %s \n",flMemStat,st);

  return flMemStat; 
}

int GetStatFM(){
  int stat;
  w32 status;
  w32 bit7 = 128;

  status = VMER32(FLASH_STATUS);
  stat = ( (status & bit7 ) == bit7 );
  return stat;
}

/*FGROUP FlMem
Returns the last 6 bits of the address counter
*/
int GetAddrFM(){
  int stat;
  w32 status;
  w32 bits = 0x7f;

  status = VMER32(FLASH_STATUS);
  stat = (status & bits);
  return stat;
}

/*FGROUP FPGA 
Monitors FPGA status by reading the status word.

Ntimes    = number of times the status word is read
Tinterval = time interval between status word reads in microseconds
*/
int MonitorStatusFPGA(int Ntimes, int Tinterval){

  int irc = 0;

  int i,j;
  int step;
  short bit[8];

  for(j=0; j<Ntimes; j++){
    step = j % 20;
    if(step == 0 ){
      /*
              123456789012345678901234567890123456789012345678901234567890 */
      printf("TIME   RY/BY   nSTATUS  CONF_DONE INIT_DONE  nCONFIG   DCLK \n");
    }
    MonitorStatus(CONFIG_STATUS, &bit[0]);
    printf("%4i",j);
    for(i=0; i<6; i++){
      printf("%5i     ",bit[i]);
    }
    printf("\n");
    usleep(Tinterval);
  }

  return irc;
}

int MonitorStatus(w32 address, short *bit){
  /*
          Reads a status word at _ address _ and decompses it into
          8 bits in array bit[8]

          irc = 0      if O.K.
                else   if some error happens
  */
  int irc = 0;
  w32 statusWord;
  int tib;
  int j;

  statusWord = VMER32(address);    /* Read the status word at address */
  /*
           Decomposing
   */
  tib = 1;
  for(j=0; j<8; j++){
    bit[j] = ( (statusWord & tib ) == tib );
    tib <<= 1;
  }

  return irc;
}

/*FGROUP FlMem 

*/
int ResetFM(){
  int irc = 0;
  irc = resetFM();
  switch(irc){
  case 0:
    printf("Reset FM: SUCCESSFULL\n");
    break;
  case 1:
    printf("Reset FM: TIMEOUT\n");
    break;
  default:
    printf("Reset FM: Unexpected IRC\n");
    break;
  }
  return irc;
}

/*FGROUP FlMem
Erase contents of the Flash Memory (must be done before writing new contents)
*/
int EraseFM(){
  int irc = 0;
  int st = 0;

  st = eraseFM();
  switch(st){
  case 0:
    printf("Chip Erase SUCCESSFULL\n");
    break;
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
    printf("Chip Erase ERROR: Timeout after command word %i\n",st);
    break;
  case 7:
    printf("Chip Erase ERROR: Erase operation canna start, FM busy\n");
    break;
  case 11:
    printf("Chip Erase ERROR: Timeout after the whole command sequence\n");
    break;
  default:
    printf("Chip Erase ERROR: Unexpected return code\n");
    break;
  }
  irc = st;

  return irc;
}

/*FGROUP FlMem
Clears Address counter for the flash memory (i.e. set it to 0)
*/
void ClearAddressFM(){
  int irc;

  printf("ClearAddressFM: Resetting the FM Address counter to 0\n");
  irc = writeFM(FLASHADD_CLEAR,0x0);
  if(irc != 0){
    printf("ClearAddressFM: Operation finished with IRC = %i\n",irc);
  }
}

/*FGROUP FlMem
Read a word from the Flash memory from a specified address
*/
int ReadAddressFM(w32 address){
  int irc = 0;
  int dato;


  while(1){
    irc = seekFM(address);
    if(irc != 0){
      printf("READ FM: Seek ERROR : ");
      switch(irc){
      case 1:
	printf("Canna reset the Address counter\n");
	break;
      case 2:
	printf("Canna perform dummy reads\n");
	break;
      default:
	printf("Error nr. %i\n",irc);
	break;
      }
      irc = 1;
      break;
    }

    irc = readFM(FLASHACCESS_NOINCR, &dato);
    if(irc != 0){
      irc = 3;
      printf("READ FM: Error while reading the ADDRESS %i\n",address);
    }else{
      irc = 0;
      printf("READ FM: ADDRESS = %d   DATA = %x   %i\n",address,dato,dato);
    }

    break;
  }

  return irc;
}

/*FGROUP FlMem
Reads Flash memory, [nbytes] are read from the FM starting at the [address]
The bytes are stored into the readBuffer
*/
int ReadBytesFM(w32 address, int nbytes){
  int irc = 0;

  while(1){
    irc = seekFM(address);
    if(irc != 0){
      printf("READ BYTES FM: Seek error: ");
      switch(irc){
      case 1:
	printf("Canna reset the address counter\n");
	break;
      case 2:
	printf("Canna perform dummy reads\n");
	break;
      default:
	printf("Seek error nr. %i\n",irc);
	break;
      }
      irc = 1;
      break;
    }

    irc = blockReadFM(nbytes);
    if(irc != 0){
      printf("READ BYTES FM: blockReadFM(...) error nr. %i\n",irc);
      irc = 2;
      break;
    }

    if(nbytes != readBuffer.nbytes){
      printf("READ BLOCK FM: Requested nr. of bytes to read: %i\n",nbytes);
      printf("               Actual nr. of bytes read:       %i\n",
	     readBuffer.nbytes);
      irc = 3;
      break;
    }

    irc = 0;
    break;
  }

  return irc;
}

/*FGROUP FlMem
Writes [dato] into the Flash Mem at [address] starting at
the [address]
*/
int WriteAddressFM(w32 address, int dato){
  int irc = 0;

  while(1){
    irc = seekFM(address);
    if(irc != 0){
      printf("Write FM: SEEK Error %i\n",irc);
      irc = 1;
      break;
    }

    irc = initWriteFM();
    if(irc != 0){
      printf("Write FM: Write command error after %i word\n",irc);
      irc =2;
      break;
    }
  

    irc = writeFM(FLASHACCESS_NOINCR,dato);
    if(irc != 0){
      printf("Write FM: Write error %i\n",irc);
      irc = 3;
    }

    break;
  }

  return irc;
}

/*FGROUP FlMem
Writes [nbytes] bytes from the wrtBuffer into the Flash mem starting at
[address]. THE CHIP MUST BE ERASED BY THE USER
*/
int WriteBytesFM(w32 address, int nbytes){
  int irc = 0;
  int st;

  while(1){
    /*
      Do we want to write any data?
     */
    if(nbytes <= 0){
      printf("WRITE BYTES FM: No data to be written? nbytes = %i\n",nbytes);
      irc = 1;
      break;
    }
    /*
      Do we have some data in wrtBuffer?
    */
    if(wrtBuffer.nbytes <= 0){
      printf("WRITE BYTES FM: No data in wrtBuffer! wrtBuffer.nbytes = %i\n",
	     wrtBuffer.nbytes);
      irc = 2;
      break;
    }
    /*
      Position the Address counter to address
     */
    st = seekFM(address);
    if(st != 0){
      printf("WRITE BYTES FM: Canna position the Address counter, IRC = %i\n",
	     st);
      irc = 3;
      break;
    }
    /*
      Write a data block to the Flash memory
    */
    st = blockWriteFM(nbytes);
    if(st != 0){
      printf("WRITE BYTES FM: Block write ERROR %i\n",st);
      irc = 4;
    }
    /*
      Check whether all data has been written
     */
    if(nbytes != wrtBuffer.count){
      printf("WRITE BYTES FM: Not all data written: REQUEST = %i\n",
	     nbytes);
      printf("                                      WRITTEN = %i\n",
	     wrtBuffer.count);
      irc = 5;
    }
    irc = 0;
    break;
  }

  return irc;
}

/*FGROUP FlMem 
Generates nbytes randomly and stores them into wrtBuffer
nbytes = 0 ----> fill full wrtBuffer
 */
int TestGenPattern(int nbytes, int iseed){
  int irc = 0;

  int nb;
  int i;
  int mask = 0xff;
  int genum;
  unsigned int seed;

  wrtBuffer.nbytes = 0;
  wrtBuffer.count = 0;

  seed = iseed; /* The Python interface cannot handle unsigned int */

  if(seed != 0){
    printf("TEST GEN PATTERN: setting seed to %i\n",seed);
    srand(seed);
  }

  if(nbytes > 0){
    nb = nbytes;
  }else{
    nb = MAX_FM_BUFFER;
  }

  for(i=0; i<nb; i++){
    genum = rand();
    wrtBuffer.buf[i] = (genum & mask);
    wrtBuffer.nbytes++;
  }

  printf("TEST GEN PATTERN: %i bytes generated\n",wrtBuffer.nbytes);
  printf("                  The first 5 bytes are\n");
  for(i=0; i<10; i++){
    printf(" %i ",wrtBuffer.buf[i]);
  }
  printf("  .\n");
  printf("TEST GEN PATTERN finished\n");

  return irc;
}

/*FGROUP FlMem
Writes nbytes bytes from wrtBuffer at the address into Flash memory,
read them into the readBuffer and compares those two
If nbytes = 0 ---> the full wrtBuffer is written and read
seed - random number seed (just to have some different rndm sequences
       0 = no reseeding
nreads = number of reads (to see that we always reed the same data)
 */
int TestWritePatternFM(w32 address, int nbytes, int seed, int nreads){
  int irc=0;

  int i, j;
  static struct bufferFM testBuffer;
  unsigned long byteError;
  unsigned char t, r;
  int nrRead = 0;

  printf("TestWritePatternFM:   STARTING \n");
  printf("                      Start Flash Mem address    = %i\n",address);
  printf("                      Nr. of bytes to Write/Read = %i\n",nbytes);

  while(1){
    /*
      Generate bit patterns
    */
    irc = TestGenPattern(nbytes,seed);
    if(irc != 0){
      printf(" Cannot generate test bit patterns IRC = %i\n",irc);
      irc = 1;
      break;
    }

    /*
      Write bit patterns into the Flash Memory, starting at address
     */
    irc = WriteBytesFM(address,nbytes);
    if(irc != 0){
      printf("Canna write test bit patterns into Flash memory IRC = %i\n",irc);
      irc = 2;
      break;
    }

    /*
      Reads the test data into the write buffer and compare them
      with the data yuou wrote in
     */
    irc = ReadBytesFM(address,nbytes);
    if(irc != 0){
      printf("Canna read the test bit patterns from Flash memory IRC = %i\n",
	     irc);
      irc = 3;
      break;
    }

    /*
      Bit by bit comparison
     */
    irc = CompWrtReadBuf(nbytes);
    if(irc != 0){
      printf("Bit by bit comparison failed IRC = %i\n",irc);
      irc = 4;
      break;
    }

    /*
      Repeatedly read and check whether the read data differ
     */
    if(nreads < 0){
      printf("Repeated reads not requested NREADS = %i\n",nreads);
      break;
    }
    byteError = 0;
    for(i=0; i<nreads; i++){
      irc = ReadBytesFM(address,nbytes);
      if(irc != 0){
	printf("Repeated read error IRC = %i\n",irc);
	irc = i*100 + irc;
	break;
      }
      nrRead++;
      if(i > 0){
	for(j=0; j<readBuffer.nbytes; j++){
	  t = testBuffer.buf[j];
	  r = readBuffer.buf[j];
	  if(t != r){
	    byteError++;
	  }
	}
      }
      for(j=0; j<readBuffer.nbytes; j++){
	testBuffer.buf[j] = readBuffer.buf[j];
      }
    }
    printf("Flash Memory read %i times, Byte errors = %li\n",
	   nrRead, byteError);
    if(irc != 0){
      break;
    }

    break;
  }

  printf("                      FINISHED WITH IRC = %i\n",irc);
  return irc;
}

int writeFM(w32 address, int dato){
  /*
      Writes to FM via VME controller

      address = FLASHACCESS_INCR          VME controller register
                FLASHACCESS_NOINCR
                FLASHADD_CLEAR

                (other adresses have no effect on FM)
  */
  int irc = 0;
  int attempts = 0;

  /*      Write data into a given address
   */
  VMEW32(address, dato);
  /*
         For a while the Flash Memory will be BUSY, but after a 
         reasonable time it must go back to READY
   */
  while( (GetStatFM() == BUSYFM) && (attempts < MAX_W_ATTEMPTS ) ){
    attempts++;
  }
  /*
         If the loop terminated without seeing the READY status
         sound an allarm
   */
  if( attempts >= MAX_W_ATTEMPTS ){
    printf("Unable to write (a:%x  data:%x) in Flash Memory \n",address,dato);
    printf("       after %i attempts\n",attempts);
    irc = 1;
  }else{
    irc = 0;
  }

  return irc;
}

int readFM(w32 address, int* dato){
  /*
    Reads from the VME register returning the value from the Flash memory

    address = FLASHACCESS_NOINCR
              FLASHACCESS_INCR
   */
  int irc = 0;
  int attempts = 0;
  int dataRead = 0;

  /*
    Read from VME register
   */

  dataRead = VMER32(address);

  while( (GetStatFM() == BUSYFM) && (attempts < MAX_R_ATTEMPTS) ){
    attempts++;
  }
  if(attempts >= MAX_R_ATTEMPTS){
    printf("Unable to read from addr:%x after %i attempts\n",address,attempts);
    irc = 1;
  }else{
    irc = 0;
    *dato = dataRead & 0xff;  /* Only 8 bits are relevant */
  }

  return irc;
}

int blockReadFM(int nbytes){ 
  /*
    Reads a block of data from FLAHACCESS_INCR and stores them to the
    readBuffer

    The address from where the data are to be read must be set by 
    seekFM(...) before calling this
  */
  int irc = 0;
  int i;
  int dato;
  int dumdat;
  int nb;
  int st;
  int mask = 0xff; /* Only 8 bit are relevant */

  if(nbytes > MAX_FM_BUFFER){
    nb = MAX_FM_BUFFER;
  }else{
    nb = nbytes;
  }
  readBuffer.count = nb;

  readBuffer.nbytes = 0; /* Clear the readBuffer */

  for(i=0; i<nb; i++){
    st = readFM(FLASHACCESS_NOINCR, &dato);  /* Read the dato */
    if(st == 0){
      readBuffer.buf[i] = ( dato & mask );
      readBuffer.nbytes++;
    }else{
      irc = -i-1;
      break;
    }
    st = readFM(FLASHACCESS_INCR, &dumdat); /* Advance the counter */
  }

  return irc;
}

int eraseFM(void){
  int irc = 0;

  int command[6] = { 0xaa, 0x55, 0x80, 0xaa, 0x55, 0x10 };
  int i;
  int st;

  if( GetStatFM() == READYFM ){
    for(i=0; i<5; i++){
      st = writeFM(FLASHACCESS_NOINCR,command[i]);
      if(st != 0){
	irc = i+1;
	break;
      }
    }
    /*
      The last command word starts erasing the memory. The process may take
      a bit longer
     */
    if(irc == 0){
      VMEW32(FLASHACCESS_NOINCR,command[5]);
      i = 0;
      while( (i < MAX_E_ATTEMPTS) && ((st = GetStatFM()) == BUSYFM )){
	usleep(ERASE_SLEEP);
	printf("%i sec: Erasing FM in progress, status = %i\n",i+1,st);
	i++;
      }
      printf("%i sec: Erasing FM in progress, status = %i\n",i+1,st);
      if( st == BUSYFM ){
	printf("Chip Erase operation not successfull\n");
	irc = 11;
      }
    }
  }else{ 
    /*
      Flash memory is busy, -> ERROR 7
    */
    irc = 7;
  }

  return irc;
}

int resetFM(void){
  int irc = 0;
  int st;

  st = writeFM(FLASHACCESS_NOINCR,0xF0);
  if(st != 0){
    irc = 1;
  }else{
    irc = 0;
  }

  return irc;
}

int seekFM(w32 address){
  int irc = 0;
  int i;
  int dato;

  while(1){
    irc = writeFM(FLASHADD_CLEAR,0x0); /* Rest the Address counter */
    if(irc != 0){
      irc = 1;
      break;
    }

    if(address == 0){ /* For address 0 we are here */
      irc = 0;
      break;
    }

    for(i=0; i<address; i++){                /* ADDRESS  dummy reads */
      irc = readFM(FLASHACCESS_INCR, &dato);
      if(irc != 0){
	break;
      }
    }
    if(irc != 0){
      irc = 2;
    }else{
      irc = 0;
    }
    /*
      Here the Address counter points to ADDRESS i.e. the next read/write 
      access the desired address
     */
    break;
  }

  return irc;
}

int initWriteFM(void){
  int irc = 0;

  int command[3] = { 0xaa, 0x55, 0xa0 };
  int i;
  int st;

  for(i=0; i<3; i++){
    st = writeFM(FLASHACCESS_NOINCR,command[i]);
    if(st != 0){
      irc = i+1;
      break;
    }
  }

  return irc;
}

int blockWriteFM(int nbytes){
  /*
    Writes nbytes bytes from wrtBuffer to Flash memory 
    to FLASHACCESS_INCR

    Erasing the Flash memory chip and positioning the Address counter
    to the desired addres by seekFM() must be done by caller
   */
  int irc = 0;
  int nb;
  int st;
  int dato;
  int dumdat;
  int i;

  if(nbytes > MAX_FM_BUFFER){
    nb = MAX_FM_BUFFER;
  }else{
    nb = nbytes;
  }
  if(nb > wrtBuffer.nbytes){
    nb = wrtBuffer.nbytes;
  }

  wrtBuffer.count = 0;
  for(i=0; i<nb; i++){
    /*
      Send the write command
     */
    st = initWriteFM();
    if(st != 0){
      irc = i+1;
      break;
    }

    /*
      Send the dato
     */
    dato = wrtBuffer.buf[i];
    st = writeFM(FLASHACCESS_NOINCR,dato);
    if(st != 0){
      irc = -i-1;
      break;
    }
    st = readFM(FLASHACCESS_INCR, &dumdat); /* Advance the counter */
    /*
      Reset the chip (for any case)
     */
    st = resetFM();
    if(st != 0){
      irc = 1000+i;
      break;
    }
    wrtBuffer.count++;
  }

  return irc;
}

/*FGROUP FlMem
 */
int CompWrtReadBuf(int nbytes){
  int irc = 0;

  irc = compareBuffers(nbytes);

  return irc;
}

int compareBuffers(int nbytes){
  int irc = 0;
  int nb;
  int five;
  int fuenf = 20;
  int i, j;

  unsigned long errorBits[8];
  unsigned long sumErrors;
  unsigned long errorBytes = 0;
  int wrtBits[8];
  int readBits[8];
  unsigned char wrtByte;
  unsigned char readByte;

  fuenf = 100;

  sumErrors = 0;
  for(i=0; i<8; i++){
    errorBits[i] = 0;
  }

  if(nbytes <= 0){
    nb = MAX_FM_BUFFER;
  }else{
    nb = nbytes;
  }

  printf("COMPARE BUFFER: Comparing wrtBuffer and readBuffer\n");
  
  if(nb > wrtBuffer.nbytes){
    nb = wrtBuffer.nbytes;
  }
  if(nb > readBuffer.nbytes){
    nb = readBuffer.nbytes;
  }
  if(nb < fuenf){
    five = nb;
  }else{
    five = fuenf;
  }

  printf("                size of wrtBuffer    = %i\n",wrtBuffer.nbytes);
  printf("                size of readBuffer   = %i\n",readBuffer.nbytes);
  printf("                REQUESTED nr of bytes to cmp %i\n",nbytes);
  printf("                Can be compared              %i\n",nb);    

  printf("                The first 5 bytes:\n");
  printf("                WRITTEN      READ\n");
  for(i=0; i<five; i++){
    printf("                %i            %i\n",wrtBuffer.buf[i],
	   readBuffer.buf[i]);
  }
  printf(" \n");
  printf("                Bit by bit comparison\n");

  for(i=0; i<nb; i++){
    /*
      Decompose readBuffer byte and wrtBuffer byte into bits
     */
    wrtByte = wrtBuffer.buf[i];
    readByte = readBuffer.buf[i];
    /*
      Compare bytes
     */
    if(wrtByte != readByte){
      errorBytes++; 
    }

    decomposeBits(wrtByte, &wrtBits[0]);
    decomposeBits(readByte, &readBits[0]);

    /*
      Compare wrt/read bit by bit and accumulate bits that do not match
     */
    for(j=0; j<8; j++){
      if(wrtBits[j] != readBits[j]){
	errorBits[j] += 1;
	sumErrors += 1;
      }
    }
  }

  /*
    Print errors 
   */
  printf("Not matching bits: 7 6 5 4 3 2 1 0 \n");
  printf("                  ");
  for(j=7; j>=0; j--){
    printf("  %lu ",errorBits[j]);
  }
  printf(" \n");
  printf(" \n");
  printf("      Comparison finished, Errorneous bits = %lu\n",sumErrors);
  printf("                           Errorneous ytes = %lu\n",errorBytes);

  return irc;
}

void decomposeBits(unsigned char Byte, int *bit){
  int i;
  int tib;

  tib = 1;
  for(i=0; i<8; i++){
    bit[i] = ((Byte & tib) == tib);
    tib <<= 1;
  }

}

/*FGROUP FPGA

Prints information about the FPGA code stored in the Flash Memory
Or nothing, if there is no such info
*/
int InfoCodeFPGA(){

  int irc = 0;

  w32 start;
  int i;

  for(i=0; i<3; i++){
    start = (3 * CONF_SIZE) + (i * HEADER_SIZE);
    irc = ReadBytesFM(start, HEADER_SIZE);
    printCodeFPGAdoc( &(readBuffer.buf));
  }

  return irc;
}

/*FGROUP FPGA

Stores the code found in the current directory into the Flash memory in the 
form


*/
int StoreCodeFPGA(){

  int irc = 0;
 
  int st;

  do{
    /*
      Read the configuration ttcit.con file
     */

    st = getConfigFile();
    if(st != 0){
      printf("Cannot read the configuration file, IRC = %d\n",st);
      irc = 1;
      break;
    }

    /*
      Move the configuration data into the write buffer
     */

    st = storeConfData(&wrtBuffer);
    if(st != 0){
      printf("Configuration data cannot be copied into the Write buffer\n");
      printf("IRC from the write operation IRC = %d\n",st);
      irc = 2;
      break;
    }

    /*
      Erase the FM
     */

    st = eraseFM();
    if(st !=0){
      printf("FM erase operation error IRC = %d\n",st);
      irc = 3;
      break;
    }

    /*
      Reset FM
     */
    st = resetFM();
    if(st != 0){
      printf("Cannot reset Flash Memory IRC = %d\n",st);
    }

    /*
      Reset the address counter to 0
     */
    ClearAddressFM();
    st = GetAddrFM();
    if(st != 0){
      printf("The address counter should show 0 but shows %X\n",st);
      irc = 4;
      break;
    }

    /*
      Store data from write buffer into the Flash Memory
     */
    st = blockWriteFM(MAX_FM_BUFFER);
    if(st != 0){
      printf("Error on Writing into the Flash Memory IRC = %d\n",st);
      irc = 5;
      break;
    }
    if(wrtBuffer.count != MAX_FM_BUFFER){
      st = MAX_FM_BUFFER - wrtBuffer.count;
      printf("The FPGA code in Flash Memory is incomplete, %d bytes missing\n",
	     st);
      irc = 6;
      break;
    }

  }while(0);

  if(irc != 0){
    printf("\n FPGA code cannot be stored in the Flash Memory\n"); 
  }else{
    printf("\n FPGA code succesfully stored in the Flash Memory\n");
  }

  return irc;
}

/*FGROUP FPGA

Loads the FPGA code from the flash mamory into the FPGA

opt = option code; this will the most probably be the configuration
      number
*/
int LoadCodeFPGA(int opt){

  int irc = 0;

  int i;
  int st;
  int nbad = 0;

  int tries = 4; /* Number of wating loops for READYFP */
  int TimeInterval = 10000; /* Nr. of micreseconds to wait for READYFP */
  int Ntimes = 10;

  w32 start;

  do{
    /*
      The First 36 bytes in Flash memory shoud not be 0xff

      At the same time do the 1-st check of the Flash Memory
    */
    st = FetchFM();
    if(st != 0){
      printf("Problems reading the Flash Memory, FPGA code loading stopped\n");
      irc = 1;
      break;
    }
    nbad = 0;
    for(i=0; i<36; i++){
      if(wrtBuffer.buf[i] == 0xff){
	nbad++;
      }
    }
    if(nbad >= 36){
      printf("\n ERROR !!! ERROR !!! ERROR !!!\n");
      printf("The Flash Memory seems to be erased \n");
      printf("Check the Flash Memory contents \n");
      printf("And load the FPGA code manually\n");
      irc = 2;
      break;
    }

    /*
      Position the Flash memory Address counter according to your choice
    */

    if((opt < 0) || (opt >= MAX_CONFIONS)){
      printf("Flash Memory cannot store %d FPGA configurations\n",opt);
      printf("Valid choices are: 0, 1 , 2\n");
      printf("Call InfoCodeFPGA() for details about FPGA configurations\n");
      irc = 4;
      break;
    }else{
      start = opt * CONF_SIZE;
      st = seekFM(start);
      if(st != 0){
	printf("The FM address counter cannot be positioned to %X\n",start);
	irc = 5;
	break;
      }
      st = GetAddrFM();
      printf("Address counter positioned to (last 6 bits) %X \n",st);
      if(st != (start & 0x7f)){
	printf("Incorrectly positioned FM address counter !!!\n");
	printf("Last 6 address bits found    = %X\n",st);
	st = start & 0x7f;
	printf("Last 6 address bits expected = %X\n",st);
	irc = 51;
	break; 
      }
    }

    /*
      Reset the Flash Memory for smooth operation
    */

    st = ResetFM();
    if(st != 0){
      printf("FM memory problem, loading FPGA code terminated\n");
      irc = 3;
      break;
    }

    /*
      Start loading the FPGA code 
     */

    st = GetStatFPGA();
    if(st != READYFP){
      printf("FPGA not ready, loadinf FPGA code cannot proceed\n");
      irc = 6;
      break;
    }

    VMEW32(CONFIG_START,0x0);
    printf("FPGA configuration started\n");
    i = 0;
    do{
      MonitorStatusFPGA(Ntimes, TimeInterval);
      GetStatusFPGA();
      i++;
      st = GetStatFPGA();
    }while((st == BUSYFP) && (i<tries));
    st = GetStatFPGA();
    if(st != READYFP){
      i = Ntimes * TimeInterval;
      printf("FPGA loading unsuccessfull, TIMEOUT after %d miliseconds \n",i);
      irc = 7;
      break;
    }
    
    printf("FPGA configuration %d loaded successfully\n",opt);
  
  }while(0);

  return irc;
}

/*FGROUP FPGA
Loads the default FPGA configuration
*/
int LoadFPGA(){
  int irc;
  irc = LoadCodeFPGA(0);
  if(irc != 0){
    printf("LoadFPGA: Canna load the default FPGA logic code!!! IRC = %d\n",
	   irc);
  }else{
    printf("Default TTTCIT logic code has been loaded into the FPGA\n"); 
  }
  return irc;
} 

int writeEOConf(){
  /*
    Writes End Of Configuration into the wrtBuffer
   */

  unsigned char EOConf = 0xff;
  int i;
  int irc = 0;
  int n;

  while(1){

    n = wrtBuffer.nbytes + 36;
    if(n > MAX_FM_BUFFER){
      irc = 1;
      break;
    }

    wrtBuffer.count = wrtBuffer.nbytes;
    for(i=0;i<36;i++){
      wrtBuffer.buf[wrtBuffer.count++] = EOConf;
      wrtBuffer.nbytes++;
    }
    break;
  }

  return irc;
}


/*FGROUP FPGA

Dumps the FM buffer, it is meant only when onw wants to check the 
configuration file (this function provides very simpleminded HEX
browser of the Flash Memory)

It shows the data to be stored into the Flash Memory

address    = starting addres for dumping bytes
data       = number of bytes to be dumped 
*/
void DumpBuffer(int address, int data){

  int i;
  int a, d;

  wrtBuffer.count = address;
  printf("Dumping %d bytes from wrtBuffer starting at address %d\n\n",
	 address, data); 

  for(i=0;i<data;i++){
    a = wrtBuffer.count;
    d = wrtBuffer.buf[wrtBuffer.count++];
    printf("Add = %d  ->  %X  %d\n",a,d,d);
  }

  printf("\n Buffer contains %d bytes\n",wrtBuffer.nbytes);
}

/*FGROUP FPGA
Fetch the contents of the Flah Memory into the buffer to be inspected 
by the DumpBuffer function.
*/
int FetchFM(){

  w32 start = 0;
  int full = MAX_FM_BUFFER;
  int irc = 0;

  int nb;
  int i;

  while(1){

    irc = ReadBytesFM(start, full);
    if(irc != 0){
      printf("FetchFM: ReadBytesFM returned %d\n",irc);
      irc =1;
      break;
    }

    nb = readBuffer.nbytes;
    printf("FetchFM: we could read \%d bytes from FM\n",nb);
    if(nb < full){
      printf("FetchFM: Full FM canna be read\n");
      irc = 2;
      break;
    }

    wrtBuffer.nbytes = 0;
    for(i=0;i<full;i++){
      wrtBuffer.buf[wrtBuffer.nbytes++] = readBuffer.buf[i];
    }
    if(wrtBuffer.nbytes != readBuffer.nbytes){
      printf("FetchFM: Canna copy the whole readBuffer: copied %d bytes\n",
	     wrtBuffer.nbytes);
      irc = 3;
      break;
    }
    printf("FetchFM: Fetched %d bytes\n",wrtBuffer.nbytes);
    break;
  }

  return irc;
}

/*ENDOFCF */
